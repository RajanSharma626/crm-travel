<?php $__env->startSection('title', 'Completed Travels | Travel Shravel'); ?>
<?php $__env->startSection('content'); ?>
    <div class="hk-pg-wrapper pb-0">
        <div class="hk-pg-body py-0">
            <div class="contactapp-wrap">
                <div class="contactapp-content">
                    <div class="contactapp-detail-wrap">
                        <div class="contact-body">
                            <div data-simplebar class="nicescroll-bar">
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                <?php endif; ?>

                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <strong>There were some problems with your submission:</strong>
                                        <ul class="mb-0">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <form method="GET" action="<?php echo e(route('completed-travels.index')); ?>" class="row g-3 mb-4"
                                    id="completedTravelsFiltersForm">
                                    <div class="col-md-4 col-lg-3">
                                        <label for="search" class="form-label">Search</label>
                                        <input type="text" name="search" id="search"
                                            class="form-control form-control-sm" placeholder="Enter name, TSQ, or phone"
                                            value="<?php echo e($filters['search'] ?? ''); ?>">
                                    </div>
                                    <div class="col-md-3 col-lg-2">
                                        <label for="service_id" class="form-label">Service</label>
                                        <select name="service_id" id="service_id" class="form-select form-select-sm">
                                            <option value="">All Services</option>
                                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($service->id); ?>"
                                                    <?php echo e(($filters['service_id'] ?? '') == $service->id ? 'selected' : ''); ?>>
                                                    <?php echo e($service->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3 col-lg-2">
                                        <label for="destination_id" class="form-label">Destination</label>
                                        <select name="destination_id" id="destination_id" class="form-select form-select-sm">
                                            <option value="">All Destinations</option>
                                            <?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($destination->id); ?>"
                                                    <?php echo e(($filters['destination_id'] ?? '') == $destination->id ? 'selected' : ''); ?>>
                                                    <?php echo e($destination->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3 col-lg-2 align-self-end">
                                        <button type="submit" class="btn btn-primary btn-sm w-100">
                                            <i class="ri-search-line me-1"></i> Filter
                                        </button>
                                    </div>
                                    <?php if(!empty($filters['search']) || !empty($filters['service_id']) || !empty($filters['destination_id'])): ?>
                                        <div class="col-md-3 col-lg-2 align-self-end">
                                            <a href="<?php echo e(route('completed-travels.index')); ?>"
                                                class="btn btn-outline-danger w-100 btn-sm">Clear Filters</a>
                                        </div>
                                    <?php endif; ?>
                                </form>

                                <!-- Completed Travels Table -->
                                <?php if(isset($leads) && $leads->count() > 0): ?>
                                <div class="text-muted small mb-2 px-3">
                                    Showing <?php echo e($leads->firstItem() ?? 0); ?> to <?php echo e($leads->lastItem() ?? 0); ?> out of <?php echo e($leads->total()); ?> completed travels
                                </div>
                                <?php endif; ?>

                                <table class="table table-striped small table-bordered w-100 mb-5" id="completedTravelsTable">
                                    <thead>
                                        <tr>
                                            <th>TSQ</th>
                                            <th>Customer Name</th>
                                            <th>Phone</th>
                                            <th>Service</th>
                                            <th>Destination</th>
                                            <th>Travel Date</th>
                                            <th>Return Date</th>
                                            <th>Assigned To</th>
                                            <th>Booking File Recent Remark</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr data-lead-id="<?php echo e($lead->id); ?>">
                                            <td><strong><?php echo e($lead->tsq); ?></strong></td>
                                            <td>
                                                <a href="<?php echo e(route('completed-travels.booking-file', $lead)); ?>"
                                                    class="text-primary text-decoration-none fw-semibold">
                                                    <?php echo e($lead->customer_name); ?>

                                                </a>
                                            </td>
                                            <td><?php echo e($lead->primary_phone ?? $lead->phone); ?></td>
                                            <td><?php echo e($lead->service->name ?? '-'); ?></td>
                                            <td><?php echo e($lead->destination->name ?? '-'); ?></td>
                                            <td><?php echo e($lead->travel_date ? $lead->travel_date->format('d M, Y') : '-'); ?></td>
                                            <td>
                                                <span class="badge bg-secondary"><?php echo e($lead->return_date ? $lead->return_date->format('d M, Y') : '-'); ?></span>
                                            </td>
                                            <td>
                                                <?php echo e($lead->assignedUser ? $lead->assignedUser->name : 'Unassigned'); ?>

                                            </td>
                                            <td>
                                                <?php if($lead->latest_booking_file_remark): ?>
                                                    <div class="d-flex align-items-start">
                                                        <div class="flex-grow-1">
                                                            <div class="small text-muted mb-1">
                                                                <strong><?php echo e($lead->latest_booking_file_remark->user->name ?? 'Unknown'); ?></strong>
                                                                <span class="ms-2"><?php echo e($lead->latest_booking_file_remark->created_at->format('d/m/Y h:i A')); ?></span>
                                                            </div>
                                                            <div class="text-truncate" style="max-width: 200px;" title="<?php echo e($lead->latest_booking_file_remark->remark); ?>">
                                                                <?php echo e(Str::limit($lead->latest_booking_file_remark->remark, 50)); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('completed-travels.booking-file', $lead)); ?>" 
                                                   class="btn btn-sm btn-outline-primary" 
                                                   title="View Booking File (Read-Only)">
                                                    <i data-feather="eye" style="width: 14px; height: 14px;"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="10" class="text-center py-4">
                                                <div class="text-muted">
                                                    <i data-feather="inbox" style="width: 48px; height: 48px; opacity: 0.3;"></i>
                                                    <p class="mt-2 mb-0">No completed travels found.</p>
                                                    <?php if(!empty($filters['search']) || !empty($filters['service_id']) || !empty($filters['destination_id'])): ?>
                                                        <p class="small">Try adjusting your filters.</p>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>

                                <!-- Pagination -->
                                <?php if(isset($leads) && $leads->hasPages()): ?>
                                <div class="d-flex justify-content-center mt-4">
                                    <?php echo e($leads->links()); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Feather icons
            if (typeof feather !== 'undefined') {
                feather.replace();
            }
        });
    </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/Crucial 1TB/Projects/Laravel-project/travel-shravel/resources/views/completed-travels/index.blade.php ENDPATH**/ ?>