<?php $__env->startSection('title', 'Destinations | Travel Shreval'); ?>

<?php $__env->startSection('content'); ?>
    <div class="hk-pg-wrapper pb-0">
        <!-- Page Body -->
        <div class="hk-pg-body py-0">
            <div class="contactapp-wrap">
                <div class="contactapp-content">
                    <div class="contactapp-detail-wrap">
                        <header class="contact-header">
                            <div class="w-100 align-items-center justify-content-between d-flex contactapp-title link-dark">
                                <h1>Destinations</h1>
                                <a href="<?php echo e(route('destinations.create')); ?>" class="btn btn-primary btn-sm">
                                    + Add Destination
                                </a>
                            </div>
                        </header>

                        <div class="contact-body">
                            <div data-simplebar class="nicescroll-bar">
                                <!-- Alerts -->
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success mt-3"><?php echo e(session('success')); ?></div>
                                <?php endif; ?>

                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger mt-3">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error); ?><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if(isset($destinations) && $destinations->count() > 0): ?>
                                <div class="text-muted small mb-2 px-3">
                                    Showing <?php echo e($destinations->firstItem() ?? 0); ?> out of <?php echo e($destinations->total()); ?>

                                </div>
                                <?php endif; ?>

                                <!-- Table -->
                                <div class="table-responsive">
                                    <table id="DestinationsTable"
                                        class="table table-striped table-bordered align-middle w-100 mb-3">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Country</th>
                                                <th>Destination Name</th>
                                                <th>Locations</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td><?php echo e(($destinations->currentPage() - 1) * $destinations->perPage() + $loop->iteration); ?></td>
                                                    <td><?php echo e($destination->country ?? '-'); ?></td>
                                                    <td><?php echo e($destination->name); ?></td>
                                                    <td>
                                                        <?php if($destination->locations && $destination->locations->count() > 0): ?>
                                                            <?php $__currentLoopData = $destination->locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span class="badge bg-primary me-1"><?php echo e($location->name); ?></span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <span class="text-muted">No locations</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('destinations.edit', $destination->id)); ?>"
                                                            class="btn btn-outline-warning btn-sm">
                                                            <i class="bi bi-pencil-square"></i> Edit
                                                        </a>
                                                        <form action="<?php echo e(route('destinations.destroy', $destination->id)); ?>"
                                                            method="POST" class="d-inline">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-outline-danger btn-sm"
                                                                onclick="return confirm('Delete this destination?')">
                                                                <i class="bi bi-trash"></i> Delete
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="5" class="text-center text-muted">
                                                        No destinations found.
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>

                                <!-- Pagination -->
                                <div class="d-flex justify-content-center mt-3">
                                    <?php echo e($destinations->links('pagination::bootstrap-5')); ?>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/Crucial 1TB/Projects/Laravel-project/travel-shravel/resources/views/destinations/index.blade.php ENDPATH**/ ?>