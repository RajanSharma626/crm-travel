<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta Tags -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'CRM App'); ?></title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="/favicon/favicon.svg" />
    <link rel="shortcut icon" href="/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="CRM" />
    <link rel="manifest" href="/favicon/site.webmanifest" />

    <!-- Daterangepicker CSS -->
    <link href="<?php echo e(asset('vendors/daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Data Table CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet"
        type="text/css" />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">


    <!-- CSS -->
    <link href="<?php echo e(asset('dist/css/style.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Page Styles -->
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <!-- Wrapper -->
    <div class="hk-wrapper" data-layout="vertical" data-layout-style="collapsed" data-hover="active" data-menu="light"
        data-footer="simple">
        <!-- Top Navbar -->
        <nav class="hk-navbar navbar navbar-expand-xl navbar-light fixed-top">
            <div class="container-fluid">
                <!-- Start Nav -->
                <div class="nav-start-wrap">
                    <button
                        class="btn btn-icon btn-rounded btn-flush-dark flush-soft-hover navbar-toggle d-xl-none"><span
                            class="icon"><span class="feather-icon"><i
                                    data-feather="align-left"></i></span></span></button>
                </div>
                <!-- /Start Nav -->

                <!-- End Nav -->
                <div class="nav-end-wrap">
                    <ul class="navbar-nav flex-row">

                        <li class="nav-item">
                            <div class="dropdown ps-2">
                                <a class="dropdown-toggle no-caret d-flex align-items-center" href="#"
                                    role="button" data-bs-display="static" data-bs-toggle="dropdown"
                                    data-dropdown-animation data-bs-auto-close="outside" aria-expanded="false">
                                    <div class="avatar avatar-rounded rounded-circle avatar-xs me-2"
                                        style="background-color: #007d88;">
                                        <span
                                            class="initial-wrap text-white"><?php echo e(strtoupper(substr(Auth::user()->name, 0, 1))); ?></span>
                                    </div>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end shadow-lg border-1 rounded-3">
                                    <div class="dropdown-header">
                                        <h6 class="fw-bold mb-0"><?php echo e(Auth::user()->name); ?></h6>
                                        <small class="text-muted">ID:
                                            <?php echo e(Auth::user()->user_id ?? (Auth::user()->login_work_email ?? 'N/A')); ?></small>
                                    </div>
                                    <div class="dropdown-divider"></div>

                                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit"
                                            class="dropdown-item d-flex align-items-center text-danger">
                                            <i class="bi bi-box-arrow-right me-2"></i> Logout
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <!-- /End Nav -->
            </div>
        </nav>
        <!-- /Top Navbar -->

        <!-- Vertical Nav -->
        <div class="hk-menu">
            <!-- Brand -->
            <div class="menu-header">
                <span>
                    <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">
                        <img src="<?php echo e(asset('dist/img/transparency Royal Blue 2-01.png')); ?>" alt="Travel Shravel"
                            style="height: 40px; width: auto;">
                    </a>
                    <button class="btn btn-icon btn-rounded btn-flush-dark flush-soft-hover navbar-toggle">
                        <span class="icon">
                            <span class="svg-icon fs-5">
                                <svg xmlns="http://www.w3.org/2000/svg"
                                    class="icon icon-tabler icon-tabler-arrow-bar-to-left" width="24" height="24"
                                    viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                    stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <line x1="10" y1="12" x2="20" y2="12"></line>
                                    <line x1="10" y1="12" x2="14" y2="16"></line>
                                    <line x1="10" y1="12" x2="14" y2="8"></line>
                                    <line x1="4" y1="4" x2="4" y2="20"></line>
                                </svg>
                            </span>
                        </span>
                    </button>
                </span>
            </div>
            <!-- /Brand -->

            <!-- Main Menu -->
            <div data-simplebar class="nicescroll-bar">
                <div class="menu-content-wrap">
                    <div class="menu-group">
                        <ul class="navbar-nav flex-column">

                            <!-- Dashboard -->
                            <li
                                class="nav-item mb-2 <?php echo e(Route::currentRouteName() == 'home' || Route::currentRouteName() == 'dashboard' ? 'active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                                    <span class="nav-icon-wrap">
                                        <span class="svg-icon">
                                            <i data-feather="home" class="small"></i>
                                        </span>
                                    </span>
                                    <span class="nav-link-text">Dashboard</span>
                                </a>
                            </li>

                            <?php
                                $isAdmin =
                                    Auth::user()->hasRole('Admin') ||
                                    Auth::user()->hasRole('Developer') ||
                                    Auth::user()->department === 'Admin';
                                $isCustomerCare =
                                    Auth::user()->hasRole('Customer Care') ||
                                    Auth::user()->department === 'Customer Care';
                            ?>

                            <!-- Customer Care - Separate Tab -->
                            <?php if($isAdmin || $isCustomerCare): ?>
                                <li class="nav-item mb-2 <?php echo e(request()->routeIs('customer-care.*') ? 'active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('customer-care.leads.index')); ?>">
                                        <span class="nav-icon-wrap">
                                            <span class="svg-icon">
                                                <i data-feather="headphones" class="small"></i>
                                            </span>
                                        </span>
                                        <span class="nav-link-text">Customer Care</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <!-- Sales Tab - Visible to Admin, Sales, Sales Manager (Hidden for Customer Care) -->
                            <?php if(
                                ($isAdmin ||
                                    Auth::user()->hasRole('Sales') ||
                                    Auth::user()->hasRole('Sales Manager') ||
                                    Auth::user()->department === 'Sales') &&
                                    !$isCustomerCare): ?>
                                <?php
                                    $isSalesActive = request()->is('leads*') || request()->is('bookings*');
                                    $isLeadsActive = request()->is('leads*');
                                    $isBookingsActive = request()->is('bookings*');
                                ?>
                                <li class="nav-item <?php echo e($isSalesActive ? 'active' : ''); ?>">
                                    <a class="nav-link" href="javascript:void(0);" data-bs-toggle="collapse"
                                        data-bs-target="#dash_chat"
                                        aria-expanded="<?php echo e($isSalesActive ? 'true' : 'false'); ?>">
                                        <span class="nav-icon-wrap">
                                            <span class="svg-icon">
                                                <i data-feather="users" class="small"></i>
                                            </span>
                                        </span>
                                        <span class="nav-link-text">Sales</span>
                                    </a>
                                    <ul id="dash_chat"
                                        class="nav flex-column nav-children collapse <?php echo e($isSalesActive ? 'show' : ''); ?>">
                                        <li class="nav-item">
                                            <ul class="nav flex-column">
                                                <li class="nav-item <?php echo e($isLeadsActive ? 'active' : ''); ?>">
                                                    <a class="nav-link <?php echo e($isLeadsActive ? 'active fw-semibold' : ''); ?>"
                                                        href="<?php echo e(route('leads.index')); ?>"><span
                                                            class="nav-link-text">Leads</span></a>
                                                </li>
                                                <li class="nav-item <?php echo e($isBookingsActive ? 'active' : ''); ?>">
                                                    <a class="nav-link <?php echo e($isBookingsActive ? 'active fw-semibold' : ''); ?>"
                                                        href="<?php echo e(route('bookings.index')); ?>"><span
                                                            class="nav-link-text">Bookings</span></a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                            <?php endif; ?>

                            <!-- Post Sales Tab - Leads + Booking File -->
                            <?php if(
                                ($isAdmin ||
                                    Auth::user()->hasRole('Post Sales') ||
                                    Auth::user()->hasRole('Post Sales Manager') ||
                                    Auth::user()->department === 'Post Sales') &&
                                    !$isCustomerCare): ?>
                                <?php
                                    $isPostActive = request()->is('post-sales*');
                                ?>
                                <li class="nav-item <?php echo e($isPostActive ? 'active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('post-sales.index')); ?>">
                                        <span class="nav-icon-wrap">
                                            <span class="svg-icon"><i data-feather="check-circle"
                                                    class="small"></i></span>
                                        </span>
                                        <span class="nav-link-text">Post Sales</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <!-- Operations Tab - Visible to Admin and Operation department only (Hidden for Customer Care) -->
                            <?php
                                $isOpsDept =
                                    $isAdmin ||
                                    Auth::user()->hasRole('Operation') ||
                                    Auth::user()->hasRole('Operation Manager') ||
                                    Auth::user()->department === 'Operation';
                                $isOpsActive = request()->is('operations*');
                            ?>
                            <?php if($isOpsDept && !$isCustomerCare): ?>
                                <li class="nav-item <?php echo e($isOpsActive ? 'active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('operations.index')); ?>">
                                        <span class="nav-icon-wrap">
                                            <span class="svg-icon"><i data-feather="clipboard"
                                                    class="small"></i></span>
                                        </span>
                                        <span class="nav-link-text">Operations</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <!-- Ticketing Tab -->
                            <?php if(($isAdmin || Auth::user()->hasRole('Ticketing') || Auth::user()->department === 'Ticketing') && !$isCustomerCare): ?>
                                <?php
                                    $isTicketActive = request()->is('ticketing*');
                                ?>
                                <li class="nav-item <?php echo e($isTicketActive ? 'active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('ticketing.index')); ?>">
                                        <span class="nav-icon-wrap">
                                            <span class="svg-icon"><i data-feather="airplay"
                                                    class="small"></i></span>
                                        </span>
                                        <span class="nav-link-text">Ticketing</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <!-- Visa Tab -->
                            <?php if(($isAdmin || Auth::user()->hasRole('Visa') || Auth::user()->department === 'Visa') && !$isCustomerCare): ?>
                                <?php
                                    $isVisaActive = request()->is('visa*');
                                ?>
                                <li class="nav-item <?php echo e($isVisaActive ? 'active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('visa.index')); ?>">
                                        <span class="nav-icon-wrap">
                                            <span class="svg-icon"><i data-feather="file-text"
                                                    class="small"></i></span>
                                        </span>
                                        <span class="nav-link-text">Visa</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <!-- Insurance Tab -->
                            <?php if(($isAdmin || Auth::user()->hasRole('Insurance') || Auth::user()->department === 'Insurance') && !$isCustomerCare): ?>
                                <?php
                                    $isInsActive = request()->is('insurance*');
                                ?>
                                <li class="nav-item <?php echo e($isInsActive ? 'active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('insurance.index')); ?>">
                                        <span class="nav-icon-wrap">
                                            <span class="svg-icon"><i data-feather="shield"
                                                    class="small"></i></span>
                                        </span>
                                        <span class="nav-link-text">Insurance</span>
                                    </a>
                                </li>
                            <?php endif; ?>



                            <!-- Accounts Tab - Visible to Admin, Accounts, Accounts Manager (Hidden for Customer Care) -->
                            <?php if(
                                ($isAdmin ||
                                    Auth::user()->hasRole('Accounts') ||
                                    Auth::user()->hasRole('Accounts Manager') ||
                                    Auth::user()->department === 'Accounts') &&
                                    !$isCustomerCare): ?>
                                <?php
                                    $isAccActive = request()->is('accounts*');
                                ?>
                                <li class="nav-item <?php echo e($isAccActive ? 'active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('accounts.index')); ?>">
                                        <span class="nav-icon-wrap">
                                            <span class="svg-icon"><i data-feather="credit-card"
                                                    class="small"></i></span>
                                        </span>
                                        <span class="nav-link-text">Accounts</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <!-- Delivery Tab - Visible to Admin, Delivery, Delivery Manager (Hidden for Customer Care) -->
                            <?php if(
                                ($isAdmin ||
                                    Auth::user()->hasRole('Delivery') ||
                                    Auth::user()->hasRole('Delivery Manager') ||
                                    Auth::user()->department === 'Delivery') &&
                                    !$isCustomerCare): ?>
                                <?php
                                    $isDelActive = request()->is('deliveries*');
                                ?>
                                <li class="nav-item <?php echo e($isDelActive ? 'active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('deliveries.index')); ?>">
                                        <span class="nav-icon-wrap">
                                            <span class="svg-icon"><i data-feather="truck" class="small"></i></span>
                                        </span>
                                        <span class="nav-link-text">Delivery</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <!-- HR Tab - Visible to Admin and HR only (Hidden for Customer Care) -->
                            <?php if(($isAdmin || Auth::user()->hasRole('HR') || Auth::user()->department === 'HR') && !$isCustomerCare): ?>
                                <li class="nav-item mb-2 <?php echo e(request()->is('hr*') ? 'active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('hr.employees.index')); ?>">
                                        <span class="nav-icon-wrap">
                                            <span class="svg-icon">
                                                <i data-feather="users" class="small"></i>
                                            </span>
                                        </span>
                                        <span class="nav-link-text">HR</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <!-- Services - Visible to all users -->
                            <li class="nav-item mb-2 <?php echo e(request()->is('services*') ? 'active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e(route('services.index')); ?>">
                                    <span class="nav-icon-wrap">
                                        <span class="svg-icon">
                                            <i data-feather="briefcase" class="small"></i>
                                        </span>
                                    </span>
                                    <span class="nav-link-text">Services</span>
                                </a>
                            </li>

                            <!-- Destinations - Visible to all users -->
                            <li class="nav-item mb-2 <?php echo e(request()->is('destinations*') ? 'active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e(route('destinations.index')); ?>">
                                    <span class="nav-icon-wrap">
                                        <span class="svg-icon">
                                            <i data-feather="map-pin" class="small"></i>
                                        </span>
                                    </span>
                                    <span class="nav-link-text">Destinations</span>
                                </a>
                            </li>

                            <!-- Hotels - Visible to all users -->
                            <li class="nav-item mb-2 <?php echo e(request()->is('hotels*') ? 'active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e(route('hotels.index')); ?>">
                                    <span class="nav-icon-wrap">
                                        <span class="svg-icon">
                                            <i data-feather="home" class="small"></i>
                                        </span>
                                    </span>
                                    <span class="nav-link-text">Hotels</span>
                                </a>
                            </li>

                            <!-- Incentives -->
                            

                            <!-- Reports -->
                            

                            <!-- Users removed - Now using HR tab to create user profiles and login details -->
                            

                            <!-- Settings -->
                            

                            <!-- Incentive Rules (Admin only) -->
                            

                        </ul>
                    </div>
                </div>
            </div>

            <!-- /Main Menu -->
        </div>
        <div id="hk_menu_backdrop" class="hk-menu-backdrop"></div>
        <!-- /Vertical Nav -->


        <!-- Main Content -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- /Main Content -->
    </div>
    <!-- /Wrapper -->

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <!-- Bootstrap Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous">
    </script>

    </script>

    
    

    <script>
        $(document).ready(function() {
            $('.assignAgentModal').on('click', function(e) {
                e.preventDefault();

                // Get leadId from data attribute
                var leadId = $(this).data('leadid');

                // Set value in modal input/display
                $('#lead_id').val(leadId);

                // Show the modal
                var modal = new bootstrap.Modal(document.getElementById('assignAgentModal'));
                modal.show();
            });
        });
    </script>



    <!-- FeatherIcons JS -->
    <script src="<?php echo e(asset('dist/js/feather.min.js')); ?>"></script>

    <!-- Fancy Dropdown JS -->
    <script src="<?php echo e(asset('dist/js/dropdown-bootstrap-extended.js')); ?>"></script>

    <!-- Simplebar JS -->
    <script src="<?php echo e(asset('vendors/simplebar/dist/simplebar.min.js')); ?>"></script>

    <!-- Data Table JS -->
    

    <!-- Daterangepicker JS -->
    <script src="<?php echo e(asset('vendors/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/daterangepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('dist/js/daterangepicker-data.js')); ?>"></script>

    <!-- Amcharts Maps JS -->
    

    <!-- Apex JS -->
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

    <!-- Init JS -->
    <script src="<?php echo e(asset('dist/js/init.js')); ?>"></script>
    <script src="<?php echo e(asset('dist/js/chips-init.js')); ?>"></script>
    

    <!-- Sidebar Menu Logic -->
    <script>
        $(document).ready(function() {
            // Keep submenu open if child is active on page load
            $('.nav-item.active').each(function() {
                const parentSubmenu = $(this).closest('.nav-children');
                if (parentSubmenu.length) {
                    parentSubmenu.addClass('show');
                    parentSubmenu.prev('.nav-link[data-bs-toggle="collapse"]').attr('aria-expanded',
                        'true');
                }
            });

            // Add fw-semibold to active submenu items on page load
            $('.nav-children .nav-link.active').addClass('fw-semibold');

            // Handle submenu collapse/expand - close others when opening one
            $('.nav-link[data-bs-toggle="collapse"]').on('click', function(e) {
                const target = $(this).data('bs-target');
                const isExpanded = $(this).attr('aria-expanded') === 'true';

                // Close other submenus
                $('.nav-link[data-bs-toggle="collapse"]').not(this).each(function() {
                    const otherTarget = $(this).data('bs-target');
                    if (otherTarget) {
                        $(otherTarget).collapse('hide');
                        $(this).attr('aria-expanded', 'false');
                    }
                });
            });

            // Update aria-expanded when collapse events fire
            $('.nav-children').on('show.bs.collapse', function() {
                $(this).prev('.nav-link[data-bs-toggle="collapse"]').attr('aria-expanded', 'true');
            });

            $('.nav-children').on('hide.bs.collapse', function() {
                $(this).prev('.nav-link[data-bs-toggle="collapse"]').attr('aria-expanded', 'false');
            });
        });
    </script>

    <!-- Page Scripts -->
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH /Volumes/Crucial 1TB/Projects/Laravel-project/crm-travel/resources/views/layouts/app.blade.php ENDPATH**/ ?>