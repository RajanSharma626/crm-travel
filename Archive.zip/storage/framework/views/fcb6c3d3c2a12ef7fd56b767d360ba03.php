<?php $__env->startSection('title', 'Add Employee | Travel Shravel'); ?>

<?php $__env->startSection('content'); ?>
    <div class="hk-pg-wrapper pb-0">
        <div class="hk-pg-body py-0">
            <div class="contactapp-wrap">
                <div class="contactapp-content">
                    <div class="contactapp-detail-wrap">
                        <header class="contact-header">
                            <div class="w-100 align-items-center justify-content-between d-flex contactapp-title link-dark">
                                <h1>Add Employee</h1>
                                <a href="<?php echo e(route('hr.employees.index')); ?>" class="btn btn-outline-secondary btn-sm">Back to
                                    List</a>
                            </div>
                        </header>

                        <div class="contact-body">
                            <div data-simplebar class="nicescroll-bar">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <strong>There were some problems with your submission:</strong>
                                        <ul class="mb-0">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <form action="<?php echo e(route('hr.employees.store')); ?>" method="POST" class="row g-4">
                                    <?php echo csrf_field(); ?>

                                    
                                    <div class="col-12">
                                        <div class="card border shadow-sm">
                                            <div class="card-header py-2 d-flex align-items-center justify-content-between">
                                                <h6 class="mb-0 text-uppercase text-muted small fw-semibold">Official
                                                    Profile</h6>
                                            </div>
                                            <div class="card-body py-3">
                                                <div class="row g-3">
                                                    <div class="col-md-3">
                                                        <label class="form-label">Employee ID</label>
                                                        <input type="text" name="employee_id"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('employee_id')); ?>" placeholder="Auto if blank">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Salutation</label>
                                                        <select name="salutation" class="form-select form-select-sm">
                                                            <option value="">Select</option>
                                                            <option value="Mr"
                                                                <?php echo e(old('salutation') == 'Mr' ? 'selected' : ''); ?>>Mr
                                                            </option>
                                                            <option value="Ms"
                                                                <?php echo e(old('salutation') == 'Ms' ? 'selected' : ''); ?>>Ms
                                                            </option>
                                                            <option value="Mrs"
                                                                <?php echo e(old('salutation') == 'Mrs' ? 'selected' : ''); ?>>Mrs
                                                            </option>
                                                            <option value="Dr"
                                                                <?php echo e(old('salutation') == 'Dr' ? 'selected' : ''); ?>>Dr
                                                            </option>
                                                            <option value="Prof"
                                                                <?php echo e(old('salutation') == 'Prof' ? 'selected' : ''); ?>>Prof
                                                            </option>
                                                            <option value="Other"
                                                                <?php echo e(old('salutation') == 'Other' ? 'selected' : ''); ?>>Other
                                                            </option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Name <span
                                                                class="text-danger">*</span></label>
                                                        <input type="text" name="name"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('name')); ?>" required>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Date of Birth</label>
                                                        <input type="date" name="date_of_birth"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('date_of_birth')); ?>">
                                                    </div>

                                                    <div class="col-md-3">
                                                        <label class="form-label">Marital Status</label>
                                                        <select name="marital_status" class="form-select form-select-sm">
                                                            <option value="">Select</option>
                                                            <option value="Single"
                                                                <?php echo e(old('marital_status') == 'Single' ? 'selected' : ''); ?>>
                                                                Single</option>
                                                            <option value="Married"
                                                                <?php echo e(old('marital_status') == 'Married' ? 'selected' : ''); ?>>
                                                                Married</option>
                                                            <option value="Divorced"
                                                                <?php echo e(old('marital_status') == 'Divorced' ? 'selected' : ''); ?>>
                                                                Divorced</option>
                                                            <option value="Widowed"
                                                                <?php echo e(old('marital_status') == 'Widowed' ? 'selected' : ''); ?>>
                                                                Widowed</option>
                                                            <option value="Other"
                                                                <?php echo e(old('marital_status') == 'Other' ? 'selected' : ''); ?>>
                                                                Other</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Department</label>
                                                        <select name="department" class="form-select form-select-sm">
                                                            <option value="">-- Select Department --</option>
                                                            <option value="Customer Care"
                                                                <?php echo e(old('department') == 'Customer Care' ? 'selected' : ''); ?>>
                                                                Customer Care</option>
                                                            <option value="Admin"
                                                                <?php echo e(old('department') == 'Admin' ? 'selected' : ''); ?>>
                                                                Admin</option>
                                                            <option value="Sales"
                                                                <?php echo e(old('department') == 'Sales' ? 'selected' : ''); ?>>Sales
                                                            </option>
                                                            <option value="Operation"
                                                                <?php echo e(old('department') == 'Operation' ? 'selected' : ''); ?>>
                                                                Operation</option>
                                                            <option value="Accounts"
                                                                <?php echo e(old('department') == 'Accounts' ? 'selected' : ''); ?>>
                                                                Accounts</option>
                                                            <option value="Post Sales"
                                                                <?php echo e(old('department') == 'Post Sales' ? 'selected' : ''); ?>>
                                                                Post Sales</option>
                                                            <option value="Delivery"
                                                                <?php echo e(old('department') == 'Delivery' ? 'selected' : ''); ?>>
                                                                Delivery</option>
                                                            <option value="Ticketing"
                                                                <?php echo e(old('department') == 'Ticketing' ? 'selected' : ''); ?>>
                                                                Ticketing</option>
                                                            <option value="Cruise"
                                                                <?php echo e(old('department') == 'Cruise' ? 'selected' : ''); ?>>
                                                                Cruise</option>
                                                            <option value="Visa"
                                                                <?php echo e(old('department') == 'Visa' ? 'selected' : ''); ?>>
                                                                Visa</option>
                                                            <option value="Insurance"
                                                                <?php echo e(old('department') == 'Insurance' ? 'selected' : ''); ?>>
                                                                Insurance</option>
                                                            <option value="HR"
                                                                <?php echo e(old('department') == 'HR' ? 'selected' : ''); ?>>HR
                                                            </option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Designation</label>
                                                        <input type="text" name="designation"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('designation')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Reporting Manager</label>
                                                        <select name="reporting_manager" class="form-select form-select-sm">
                                                            <option value="">Select</option>
                                                            <option value="Sales Manager"
                                                                <?php echo e(old('reporting_manager') == 'Manager' ? 'selected' : ''); ?>>
                                                                Manager</option>

                                                            <option value="Admin"
                                                                <?php echo e(old('reporting_manager') == 'Admin' ? 'selected' : ''); ?>>
                                                                Admin</option>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <label class="form-label">Blood Group</label>
                                                        <input type="text" name="blood_group"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('blood_group')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Branch / Location</label>
                                                        <input type="text" name="branch_location"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('branch_location')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Date of Joining</label>
                                                        <input type="date" name="doj"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('doj')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Date of Leaving</label>
                                                        <input type="date" name="dol"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('dol')); ?>">
                                                    </div>

                                                    <div class="col-md-3">
                                                        <label class="form-label">Employment Type</label>
                                                        <select name="employment_type" class="form-select form-select-sm">
                                                            <option value="">Select</option>
                                                            <option value="Contract"
                                                                <?php echo e(old('employment_type') == 'Contract' ? 'selected' : ''); ?>>
                                                                Contract</option>
                                                            <option value="Permanent"
                                                                <?php echo e(old('employment_type') == 'Permanent' ? 'selected' : ''); ?>>
                                                                Permanent</option>
                                                            <option value="Intern"
                                                                <?php echo e(old('employment_type') == 'Intern' ? 'selected' : ''); ?>>
                                                                Intern</option>
                                                            <option value="Consultant"
                                                                <?php echo e(old('employment_type') == 'Consultant' ? 'selected' : ''); ?>>
                                                                Consultant</option>
                                                            <option value="Other"
                                                                <?php echo e(old('employment_type') == 'Other' ? 'selected' : ''); ?>>
                                                                Other</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Employment Status</label>
                                                        <select name="employment_status"
                                                            class="form-select form-select-sm">
                                                            <option value="">Select</option>
                                                            <option value="Active"
                                                                <?php echo e(old('employment_status') == 'Active' ? 'selected' : ''); ?>>
                                                                Active</option>
                                                            <option value="Resigned"
                                                                <?php echo e(old('employment_status') == 'Resigned' ? 'selected' : ''); ?>>
                                                                Resigned</option>
                                                            <option value="Terminated"
                                                                <?php echo e(old('employment_status') == 'Terminated' ? 'selected' : ''); ?>>
                                                                Terminated</option>
                                                            <option value="On Notice"
                                                                <?php echo e(old('employment_status') == 'On Notice' ? 'selected' : ''); ?>>
                                                                On Notice</option>
                                                            <option value="On Hold"
                                                                <?php echo e(old('employment_status') == 'On Hold' ? 'selected' : ''); ?>>
                                                                On Hold</option>
                                                            <option value="Completed"
                                                                <?php echo e(old('employment_status') == 'Completed' ? 'selected' : ''); ?>>
                                                                Completed</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Starting Salary</label>
                                                        <input type="number" step="0.01" name="starting_salary"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('starting_salary')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Last Withdrawn Salary</label>
                                                        <input type="number" step="0.01" name="last_withdrawn_salary"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('last_withdrawn_salary')); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <div class="col-12">
                                        <div class="card border shadow-sm">
                                            <div class="card-header py-2">
                                                <h6 class="mb-0 text-uppercase text-muted small fw-semibold">Login Details
                                                </h6>
                                            </div>
                                            <div class="card-body py-3">
                                                <div class="row g-3">
                                                    <div class="col-md-3">
                                                        <label class="form-label">User ID</label>
                                                        <input type="text" name="user_id"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('user_id')); ?>"
                                                            placeholder="sales1 / ops1 / ps1">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Work E-mail</label>
                                                        <input type="email" name="email"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('email')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Password</label>
                                                        <input type="password" name="password"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('password')); ?>" placeholder="Enter password">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label fw-semibold">Role <span
                                                                class="text-danger">*</span></label>
                                                        <select name="role" class="form-select form-select-sm"
                                                            required>
                                                            <option value="">-- Select Role --</option>
                                                            <option value="Admin"
                                                                <?php echo e(old('role') == 'Admin' ? 'selected' : ''); ?>>Admin
                                                            </option>
                                                            <option value="Manager"
                                                                <?php echo e(old('role') == 'Manager' ? 'selected' : ''); ?>>Manager
                                                            </option>
                                                            <option value="User"
                                                                <?php echo e(old('role') == 'User' ? 'selected' : ''); ?>>User</option>
                                                        </select>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <div class="col-12">
                                        <div class="card border shadow-sm">
                                            <div class="card-header py-2">
                                                <h6 class="mb-0 text-uppercase text-muted small fw-semibold">Basic
                                                    Information</h6>
                                            </div>
                                            <div class="card-body py-3">
                                                <div class="row g-3">
                                                    <div class="col-md-3">
                                                        <label class="form-label">Previous Employer</label>
                                                        <input type="text" name="previous_employer"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('previous_employer')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Contact Person</label>
                                                        <input type="text" name="previous_employer_contact_person"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('previous_employer_contact_person')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Contact Number</label>
                                                        <input type="text" name="previous_employer_contact_number"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('previous_employer_contact_number')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Reason for Leaving</label>
                                                        <input type="text" name="reason_for_leaving"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('reason_for_leaving')); ?>">
                                                    </div>

                                                    <div class="col-md-3">
                                                        <label class="form-label">Highest Qualification</label>
                                                        <input type="text" name="highest_qualification"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('highest_qualification')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Specialization</label>
                                                        <input type="text" name="specialization"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('specialization')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Year of Passing</label>
                                                        <select name="year_of_passing"
                                                            class="form-control form-control-sm">
                                                            <option value="">Select Year</option>
                                                            <?php
                                                                $startYear = date('Y');
                                                                $endYear = $startYear - 60;
                                                            ?>
                                                            <?php for($year = $startYear; $year >= $endYear; $year--): ?>
                                                                <option value="<?php echo e($year); ?>"
                                                                    <?php echo e(old('year_of_passing') == $year ? 'selected' : ''); ?>>
                                                                    <?php echo e($year); ?></option>
                                                            <?php endfor; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Work Experience</label>
                                                        <input type="text" name="work_experience"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('work_experience')); ?>">
                                                    </div>

                                                    <div class="col-md-3">
                                                        <label class="form-label">Father / Mother's Name</label>
                                                        <input type="text" name="father_mother_name"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('father_mother_name')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Father / Mother's Contact</label>
                                                        <input type="text" name="father_mother_contact_number"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('father_mother_contact_number')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Nominee Name</label>
                                                        <input type="text" name="nominee_name"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('nominee_name')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Nominee Contact</label>
                                                        <input type="text" name="nominee_contact_number"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('nominee_contact_number')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Emergency Contact</label>
                                                        <input type="text" name="emergency_contact"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('emergency_contact')); ?>"
                                                            placeholder="Emergency contact number">
                                                    </div>

                                                    <div class="col-md-3">
                                                        <label class="form-label">Aadhar Number</label>
                                                        <input type="text" name="aadhar_number"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('aadhar_number')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">PAN Number</label>
                                                        <input type="text" name="pan_number" id="panNumber"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('pan_number')); ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label">Passport Number</label>
                                                        <input type="text" name="passport_number"
                                                            class="form-control form-control-sm"
                                                            value="<?php echo e(old('passport_number')); ?>">
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <div class="col-12">
                                        <div class="card border shadow-sm">
                                            <div class="card-header py-2">
                                                <h6 class="mb-0 text-uppercase text-muted small fw-semibold">Address</h6>
                                            </div>
                                            <div class="card-body py-3">
                                                <div class="row g-3">
                                                    <div class="col-md-6">
                                                        <label class="form-label">Present Address</label>
                                                        <textarea name="present_address" rows="2" class="form-control form-control-sm"><?php echo e(old('present_address')); ?></textarea>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label">Permanent Address</label>
                                                        <textarea name="permanent_address" rows="2" class="form-control form-control-sm"><?php echo e(old('permanent_address')); ?></textarea>
                                                        <div class="form-check mt-1">
                                                            <input class="form-check-input" type="checkbox"
                                                                name="permanent_same_as_present" value="1"
                                                                id="permanentSameAsPresent"
                                                                <?php echo e(old('permanent_same_as_present') ? 'checked' : ''); ?>>
                                                            <label class="form-check-label small"
                                                                for="permanentSameAsPresent">
                                                                Same as Present?
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="col-12">
                                            <div class="card border shadow-sm">
                                                <div class="card-header py-2">
                                                    <h6 class="mb-0 text-uppercase text-muted small fw-semibold">Incentive
                                                        & Performance</h6>
                                                </div>
                                                <div class="card-body py-3">
                                                    <div class="row g-3">
                                                        <div class="col-md-3">
                                                            <label class="form-label">Incentive Eligibility</label>
                                                            <select name="incentive_eligibility"
                                                                class="form-control form-control-sm">
                                                                <option value="">Select</option>
                                                                <option value="Yes"
                                                                    <?php echo e(old('incentive_eligibility') == 'Yes' ? 'selected' : ''); ?>>
                                                                    Yes</option>
                                                                <option value="No"
                                                                    <?php echo e(old('incentive_eligibility') == 'No' ? 'selected' : ''); ?>>
                                                                    No</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Incentive Type</label>
                                                            <select name="incentive_type"
                                                                class="form-control form-control-sm">
                                                                <option value="">Select Type</option>
                                                                <option value="Fixed"
                                                                    <?php echo e(old('incentive_type') == 'Fixed' ? 'selected' : ''); ?>>
                                                                    Fixed</option>
                                                                <option value="Percentage"
                                                                    <?php echo e(old('incentive_type') == 'Percentage' ? 'selected' : ''); ?>>
                                                                    Percentage</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Monthly Target</label>
                                                            <input type="text" name="monthly_target"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('monthly_target')); ?>">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Incentive Payout Date</label>
                                                            <input type="date" name="incentive_payout_date"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('incentive_payout_date')); ?>"
                                                                placeholder="e.g. 21 of every month">
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="col-12">
                                            <div class="card border shadow-sm">
                                                <div class="card-header py-2">
                                                    <h6 class="mb-0 text-uppercase text-muted small fw-semibold">Statutory
                                                        & Payroll Details</h6>
                                                </div>
                                                <div class="card-body py-3">
                                                    <div class="row g-3">
                                                        <div class="col-md-3">
                                                            <label class="form-label">Bank Name</label>
                                                            <input type="text" name="bank_name"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('bank_name')); ?>">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Account Number</label>
                                                            <input type="text" name="account_number"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('account_number')); ?>">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">IFSC Code</label>
                                                            <input type="text" name="ifsc_code"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('ifsc_code')); ?>">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Salary Structure</label>
                                                            <select name="salary_structure"
                                                                class="form-control form-control-sm">
                                                                <option value="">Select</option>
                                                                <option value="CTC"
                                                                    <?php echo e(old('salary_structure') == 'CTC' ? 'selected' : ''); ?>>
                                                                    CTC</option>
                                                                <option value="Gross"
                                                                    <?php echo e(old('salary_structure') == 'Gross' ? 'selected' : ''); ?>>
                                                                    Gross</option>
                                                                <option value="Net"
                                                                    <?php echo e(old('salary_structure') == 'Net' ? 'selected' : ''); ?>>
                                                                    Net</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">PF Number</label>
                                                            <input type="text" name="pf_number"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('pf_number')); ?>">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">ESIC Number</label>
                                                            <input type="text" name="esic_number"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('esic_number')); ?>">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">UAN Number</label>
                                                            <input type="text" name="uan_number"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('uan_number')); ?>">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">PAN Card Number</label>
                                                            <input type="text" id="panCardNumber"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('pan_number')); ?>" readonly
                                                                style="background-color: #f8f9fa; cursor: not-allowed;">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="col-12">
                                            <div class="card border shadow-sm">
                                                <div class="card-header py-2">
                                                    <h6 class="mb-0 text-uppercase text-muted small fw-semibold">Exit &
                                                        Clearance</h6>
                                                </div>
                                                <div class="card-body py-3">
                                                    <div class="row g-3">
                                                        <div class="col-md-3">
                                                            <label class="form-label">Exit Initiated By</label>
                                                            <select name="exit_initiated_by"
                                                                class="form-control form-control-sm">
                                                                <option value="">Select</option>
                                                                <option value="Employee"
                                                                    <?php echo e(old('exit_initiated_by') == 'Employee' ? 'selected' : ''); ?>>
                                                                    Employee</option>
                                                                <option value="HR"
                                                                    <?php echo e(old('exit_initiated_by') == 'HR' ? 'selected' : ''); ?>>
                                                                    HR</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Resignation Date</label>
                                                            <input type="date" name="resignation_date"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('resignation_date')); ?>">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Notice Period</label>
                                                            <input type="text" name="notice_period"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('notice_period')); ?>">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Last Working Day</label>
                                                            <input type="date" name="last_working_day"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('last_working_day')); ?>">
                                                        </div>
                                                       

                                                        <div class="col-md-3">
                                                            
                                                            <label class="form-label" for="serviceCertificateIssued">
                                                                Service Certificate Issued
                                                            </label>

                                                            <select name="service_certificate_issued"
                                                                class="form-control form-control-sm">
                                                                <option value="">Select</option>
                                                                <option value="Yes"
                                                                    <?php echo e(old('service_certificate_issued') == 'Yes' ? 'selected' : ''); ?>>
                                                                    Yes</option>
                                                                <option value="No"
                                                                    <?php echo e(old('service_certificate_issued') == 'No' ? 'selected' : ''); ?>>
                                                                    No</option>
                                                            </select>

                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Issuing Date</label>
                                                            <input type="date" name="service_certificate_issue_date"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e(old('service_certificate_issue_date')); ?>">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Credit Card Handed Over?</label>
                                                            <select name="credit_card_handover"
                                                                class="form-control form-control-sm">
                                                                <option value="">Select</option>
                                                                <option value="Given"
                                                                    <?php echo e(old('credit_card_handover') == 'Given' ? 'selected' : ''); ?>>
                                                                    Given</option>
                                                                <option value="Returned"
                                                                    <?php echo e(old('credit_card_handover') == 'Returned' ? 'selected' : ''); ?>>
                                                                    Returned</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Laptop Handed Over?</label>
                                                            <select name="handed_over_laptop"
                                                                class="form-control form-control-sm">
                                                                <option value="">Select</option>
                                                                <option value="Given"
                                                                    <?php echo e(old('handed_over_laptop') == 'Given' || old('handed_over_laptop') == '1' ? 'selected' : ''); ?>>
                                                                    Given</option>
                                                                <option value="Returned"
                                                                    <?php echo e(old('handed_over_laptop') == 'Returned' ? 'selected' : ''); ?>>
                                                                    Returned</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">Mobile Handed Over?</label>
                                                            <select name="handed_over_mobile"
                                                                class="form-control form-control-sm">
                                                                <option value="">Select</option>
                                                                <option value="Given"
                                                                    <?php echo e(old('handed_over_mobile') == 'Given' || old('handed_over_mobile') == '1' ? 'selected' : ''); ?>>
                                                                    Given</option>
                                                                <option value="Returned"
                                                                    <?php echo e(old('handed_over_mobile') == 'Returned' ? 'selected' : ''); ?>>
                                                                    Returned</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">ID Card Handed Over?</label>
                                                            <select name="handed_over_id_card"
                                                                class="form-control form-control-sm">
                                                                <option value="">Select</option>
                                                                <option value="Given"
                                                                    <?php echo e(old('handed_over_id_card') == 'Given' || old('handed_over_id_card') == '1' ? 'selected' : ''); ?>>
                                                                    Given</option>
                                                                <option value="Returned"
                                                                    <?php echo e(old('handed_over_id_card') == 'Returned' ? 'selected' : ''); ?>>
                                                                    Returned</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">All Dues Cleared?</label>
                                                            <select name="all_dues_cleared"
                                                                class="form-control form-control-sm">
                                                                <option value="">Select</option>
                                                                <option value="Given"
                                                                    <?php echo e(old('all_dues_cleared') == 'Given' || old('all_dues_cleared') == '1' ? 'selected' : ''); ?>>
                                                                    Given</option>
                                                                <option value="Returned"
                                                                    <?php echo e(old('all_dues_cleared') == 'Returned' ? 'selected' : ''); ?>>
                                                                    Returned</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <label class="form-label">Exit Interview Notes</label>
                                                                <textarea name="exit_interview_notes" rows="3" class="form-control form-control-sm"><?php echo e(old('exit_interview_notes')); ?></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-12 mt-4">
                                        <div class="d-flex justify-content-end gap-2">
                                            <a href="<?php echo e(route('hr.employees.index')); ?>"
                                                class="btn btn-light border btn-sm">Cancel</a>
                                            <button type="submit" class="btn btn-primary btn-sm">Save
                                                Employee</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const panNumberInput = document.getElementById('panNumber');
                const panCardNumberInput = document.getElementById('panCardNumber');

                if (panNumberInput && panCardNumberInput) {
                    // Sync on input
                    panNumberInput.addEventListener('input', function() {
                        panCardNumberInput.value = this.value;
                    });

                    // Sync on page load (for old values)
                    panCardNumberInput.value = panNumberInput.value;
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home1/jrppsnmy/public_html/crm/resources/views/hr/employees/create.blade.php ENDPATH**/ ?>