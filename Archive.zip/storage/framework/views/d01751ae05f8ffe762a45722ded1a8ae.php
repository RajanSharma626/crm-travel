<div class="hk-footer border-0">
    <footer class="container-xxl footer">
        <div class="row">
            <div class="col-xl-8 text-center">
                <p class="footer-text pb-0">
                    <span class="copy-text">© <?php echo e(date('Y')); ?> All rights reserved.</span>
                    <span class="footer-link-sep">|</span>
                    <span>Designed & Developed By </span>
                    <a href="https://www.fiverr.com/rajansharma626" target="_blank">Rajan Sharma</a>
                </p>
            </div>
    </footer>
</div>
<?php /**PATH /home1/jrppsnmy/public_html/crm/resources/views/layouts/footer.blade.php ENDPATH**/ ?>